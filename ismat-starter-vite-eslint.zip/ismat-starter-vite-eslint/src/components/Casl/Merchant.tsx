import { Can } from './Casl'

const Merchant = () => (
    <div>
        <h2>Merchant Title </h2>
        <Can I="update" a="merchant">
            <button>Edit</button>
        </Can>
        <Can I="update" a="Post">
            <button>Edit</button>
        </Can>
        <Can I="delete" a="merchant">
            <button>Delete</button>
        </Can>
    </div>
)

export default Merchant
