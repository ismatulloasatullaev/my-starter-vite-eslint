import { createContext } from 'react'
import { createContextualCan } from '@casl/react'

import ability from '../../abilities/ability'

import Merchant from './Merchant'

export const AbilityContext = createContext(ability)
export const Can = createContextualCan(AbilityContext.Consumer)

const Casl = () => (
    <AbilityContext.Provider value={ability}>
        <Can I="add" a="merchant">
            <button>Add</button>
        </Can>
        <Can I="update" a="merchant">
            <Merchant />
        </Can>
    </AbilityContext.Provider>
)

export default Casl
