const Item = (props: { value: string }) => {
    console.log(1234)

    return <div>{props.value}</div>
}

export default Item
