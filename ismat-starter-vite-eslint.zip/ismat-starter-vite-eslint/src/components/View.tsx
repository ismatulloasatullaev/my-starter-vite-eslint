import React, { useState } from 'react'

interface IProps {
    enabled: boolean
}

const View: React.FC<IProps> = ({ enabled }) => {
    const [set, setSet] = useState()

    return (
        <div>
            View
            <div>{enabled}</div>
        </div>
    )
}

export default View
