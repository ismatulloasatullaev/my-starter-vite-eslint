import type { RouteObject } from 'react-router-dom'

import Casl from 'pages/Casl'
import Home from 'pages/Home'

const routes: RouteObject[] = [
    {
        path: '/',
        element: Home(),
    },
    {
        path: '/casl',
        element: Casl(),
    },
]

export default routes
