import React from 'react'

const ThemeContext: React.FC = () => <div>ThemeContext</div>

export default ThemeContext
