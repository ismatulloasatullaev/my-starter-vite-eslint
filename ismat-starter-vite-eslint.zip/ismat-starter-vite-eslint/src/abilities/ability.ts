import { defineAbility } from '@casl/ability'

export default defineAbility((can, cannot) => {
    can('read', 'merchant')
    can('add', 'merchant')
    can('update', 'merchant')
    // cannot('update', 'merchant')
    cannot('delete', 'merchant')
})
